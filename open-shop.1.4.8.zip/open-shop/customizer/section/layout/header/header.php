<?php
/**
 * Header Options for  Open Shop Theme.
 *
 * @package      Open Shop
 * @author       Open Shop
 * @since        Open Shop 1.0.0
 */
$wp_customize->get_control( 'header_image' )->section = 'open-shop-abv-header-clr';
$wp_customize->get_control( 'header_image' )->priority = 1;
